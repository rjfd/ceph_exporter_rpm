// Package collectors provides a number of Prometheus collectors which are
// capable of retrieving metrics from a Ceph cluster.
package collectors
